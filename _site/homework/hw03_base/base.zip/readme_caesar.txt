**********************************************************************
 *  Hail Caesar Java readme.txt template
**********************************************************************

Name: 
PennKey: 
Hours to complete assignment (optional):

**********************************************************************
 *  Describe any serious problems you encountered.                    
**********************************************************************





**********************************************************************
 *  What are the benefits of using functions?                   
**********************************************************************





**********************************************************************
 *  What are any flaws you can come up with regarding the use of a
 *  Caesar Cipher to store sensitive data?                 
**********************************************************************




**********************************************************************
 *  Encrypt the following message with a key value of G, write the 
 *  output below:
 *  "No one is so brave that he is not disturbed by something 
 *	unexpected"
**********************************************************************





**********************************************************************
 *  Crack encrypted_message and output the first sentence of the 
    decrypted message below
**********************************************************************







 **********************************************************************
 *  Please list all help, collaboration, and outside resources
 *  you used here. 
 *
 *  If you did not get any help in outside of TA office hours,
 *  and did not use any materials outside of the standard
 *  course materials and piazza, write the following statement below:
 *  "I did not receive any help outside of TA office hours.  I
 *  did not collaborate with anyone, and I did not use any
 *  resources beyond the standard course materials."
 **********************************************************************





**********************************************************************
 *  List any other comments here                   
**********************************************************************




