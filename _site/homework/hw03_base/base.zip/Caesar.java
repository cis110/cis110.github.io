/**
 * Name:
 * Pennkey:
 * Execution:
 * 
 * Program Description
 */

public class Caesar {

    /*
    * Description: converts a string to a symbol array,
    *              where each element of the array is an
    *              integer encoding of the corresponding
    *              element of the string.
    * Input:  the message text to be converted
    * Output: integer encoding of the message
    */
    public static int[] stringToSymbolArray(String str) {
        // TODO: Implement
        return null;
    }

    /*
    * Description: converts an array of symbols to a string,
    *              where each element of the array is an
    *              integer encoding of the corresponding
    *              element of the string.
    * Input:  integer encoding of the message
    * Output: the message text
    */
    public static String symbolArrayToString(int[] symbols) {
        // TODO: Implement
        return null;
    }

    /**
     * TODO: Add Method Header
     */
    public static int shift(int symbol, int offset) {
        // TODO: Implement
        return 0;
    }

    /**
     * TODO: Add Method Header
     */
    public static int unshift(int symbol, int offset) {
        // TODO: Implement
        return 0;
    }

    /**
     * TODO: Add Method Header
     */
    public static String encrypt(String message, int key) {
        // TODO: Implement
        return null;
    }

    /**
     * TODO: Add Method Header
     */
    public static String decrypt(String cipher, int key) {
        // TODO: Implement
        return null;
    }

    /**
     * TODO: Add Method Header
     */
    public static double[] getDictionaryFrequencies(String filename) {
        // TODO: Implement
        return null;
    }

    /**
     * TODO: Add Method Header
     */
    public static double[] findFrequencies(int[] symbols) {
        // TODO: Implement
        return null;
    }

    /**
     * TODO: Add Method Header
     */
    public static double scoreFrequencies(double[] english, double[] currentFreqs) {
        // TODO: Implement
        return 0.0;
    }

    public static void main(String[] args) {

    }

}