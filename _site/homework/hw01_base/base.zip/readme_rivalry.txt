/**********************************************************************
 *  readme template
 *  HW1: Rivalry
 **********************************************************************/

Name:
PennKey:
Hours to complete assignment (optional):



/**********************************************************************
 *  Please list all help, collaboration, and outside resources
 *  you used here. 
 *
 *  If you did not get any help in outside of TA office hours,
 *  and did not use any materials outside of the standard
 *  course materials and piazza, write the following statement below:
 *  "I did not receive any help outside of TA office hours.  I
 *  did not collaborate with anyone, and I did not use any
 *  resources beyond the standard course materials."
 **********************************************************************/









/**********************************************************************
 *  Describe any serious problems you encountered.                    
 **********************************************************************/




/**********************************************************************
 *  If you completed the extra credit or added any additional features,
 *  provide DETAILED and CLEAR instructions for how to use them and 
 *  what we should look for when grading your assignment.
 *********************************************************************/




/**********************************************************************
 *  List any other comments here.                                     
 **********************************************************************/

