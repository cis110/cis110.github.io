public class LetterViewer {
    public static void main(String[] args) {
        // TODO: set the canvas size and font size here

        // turn on animation
        PennDraw.enableAnimation(30);

        while (true) {
            // TODO: check for a key press.

            // TODO: if a key is pressed, store its value.

            // TODO: draw the most recently pressed key.

            // advance the frame after everything has been drawn for this loop
            PennDraw.advance();
        }
    }
}