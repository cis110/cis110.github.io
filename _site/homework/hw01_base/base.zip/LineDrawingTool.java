public class LineDrawingTool {
    public static void main(String[] args) {
        // TODO: set the canvas size and the pen radius.
        PennDraw.setCanvasSize(500, 500);
        PennDraw.setPenRadius(0.01);

        // TODO: create two variables to store the coordinates of the *last* click.

       
        while (true) {
            // TODO: check for mouse click
            
            // TODO: if mouse has been pressed, draw new line

            /* TODO: if mouse has been pressed, update coordinates
             * of previous click location. */
        }
    }
}
