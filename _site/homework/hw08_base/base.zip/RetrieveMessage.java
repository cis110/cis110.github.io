/* *
 * Name: Benjamin Robinov
 * PennKey: brobinov
 * Recitation #: 219
*/

public class RetrieveMessage {
    public static void main(String[] args) {
        String filename = args[0];
        // create array of size highest multiple of in image size
        int[][] pixelArr = ImageData.load(filename);
        int size = pixelArr.length * pixelArr[0].length;
        int rem = size % 7;
        int[] bits = new int[size - rem];
        int k = 0;
        int bit;
        String message;
        String character = "";
        int end = 0;
        
        // puts LSBs in bits array
        for (int i = 0; i < pixelArr.length; i++) {
            for (int j = 0; j < pixelArr[0].length - end; j++) {
                if (i == pixelArr.length - 1) {
                    end = rem;
                }
                // if pixel is odd, LSB is 1
                if (pixelArr[i][j] % 2 == 1) {
                    bit = 1;
                }
                // if pixel is even, LSB is 0
                else {
                    bit = 0;
                }
                bits[k] = bit;
                k++;
                
                
            }
        }
        // if seed and tap position provided, decrypt
        if (args.length > 1) {
            String seed = args[1];
            int tapPosition = Integer.parseInt(args[2]);
            Codec.decrypt(bits, seed, tapPosition);
            
        } 
        // decode message
        message = Codec.decode(bits);
        // stop before NULL char or entire thing if no NULL
        int stop = message.indexOf('\0');
        if (stop == -1) {
            stop = message.length();
        }
        String rightMessage = message.substring(0, stop);
        System.out.println(rightMessage);
        
    }
    
    
}