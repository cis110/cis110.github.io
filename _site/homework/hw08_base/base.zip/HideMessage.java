public class HideMessage {

	public static void main(String[] args){
		String img = args[0];
		String txtFile = args[1];
		String seed = null;
		int tapPosition = 0;

		String[] imgParts = img.split(".");
		if (!imgParts[1].equals("png")) {
			throw new IllegalArgumentException("image must be png format");
		}

		if (args.length > 2) {
			seed = args[2];
			tapPosition = Integer.parseInt(args[3]);
		}

		int[][] imgData = ImageData.load(img);

		In inFile = new In(txtFile);
		String message = inFile.readAll();
		if (message.indexOf('\0') == -1) {
			message += '\0';
		}

		int[] m = Codec.encode(message);

		if (seed != null) {
			Codec.encrypt(m, seed, tapPosition);
		}

		for (int i = 0; i < m.length; i++) {
			int r = i / imgData[0].length;
			int c = i % imgData[0].length;
			if (imgData[r][c] % 2 != m[i]) {
				if(imgData[r][c] % 2 == 0) {
						imgData[r][c]++;
					} else {
						imgData[r][c]--;
					}
			}
		}

		String newFilename = imgParts[0] + "_hidden.png";

		ImageData.save(imgData, newFilename);

	}
}