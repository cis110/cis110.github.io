public class StationaryPlatform implements Platform {
    
    // fields
    private double x;
    private double y;
    public final static double WIDTH = 0.2;
    public final static double HEIGHT = 0.05;
    
    public StationaryPlatform(double x, double y) {
        // todo error check args
        this.x = x;
        this.y = y;
    }
    
    
    
    /** Draw the platform onscreen
      * @param yOffset the y coordinate of the bottom of the window
      */
    public void draw(double yOffset) {
        PennDraw.setPenColor(0, 150, 0);
        PennDraw.filledRectangle(x, y - yOffset, WIDTH/2, HEIGHT/2);
    }
    
    
    /** Handles motion, if any, of the platform
      */
    public void update() {
        // Do nothing
    }
    
    /** Detects whether or not Doodle's feet collide with the top half of the platform
      * @param d - Doodle
      * @return whether or not Doodle's feet collided with the top half of the platform
      */
    public boolean collision(Doodle d) {
        if(d.getYVel() < 0 && d.getY() - Doodle.HEIGHT / 2 > this.y) {
            // Horizontal overlap test
            double xDist = Math.abs(this.x - d.getX());
            boolean xOverlap = xDist <= StationaryPlatform.WIDTH / 2 + Doodle.WIDTH / 2;
            // Vertical overlap test
            double yDist = Math.abs(this.y - d.getY());
            boolean yOverlap = yDist <= StationaryPlatform.HEIGHT / 2 + Doodle.HEIGHT / 2;
            
            return xOverlap && yOverlap;
        }
        else {
            return false;
        }
    }
    
    
    /** Getter for the platform's y coordinate
      * @return the platform's y coordinate
      */
    public double getY() {
        return y;
    }
    
    /** Getter for the platform's height
      * @return the platform's height
      */
    public double getHeight() {
        return HEIGHT;
    }
    
    
    
    public static void main(String[] args) {
        PennDraw.setCanvasSize(500, 500);
        PennDraw.enableAnimation(30);
        
        Platform[] platforms = new Platform[10];
        for (int i = 0; i < platforms.length; i++) {
            platforms[i] = new StationaryPlatform(Math.random(), Math.random()*5);
        }
        
        double y = 0;
        
        while (true) {
            PennDraw.clear(PennDraw.WHITE);
            
            for (Platform p : platforms) {
                p.draw(y);
            }
            
            y += 0.005;
            PennDraw.advance();
        }
    }
}