
public class Doodle {
    private double xPos, yPos;
    private double xVel, yVel;
    // tunable parameters
    public final static double WIDTH = 0.15;
    public final static double HEIGHT = 0.175;
    public final static double JUMP_VELOCITY = 0.035;
    public final static double GRAVITY = 0.001;
    public final static double HORIZONTAL_MOVE = 0.002;
    
    public Doodle(double xPos, double yPos) {
        this.xPos = xPos;
        this.yPos = yPos;
        xVel = 0;
        yVel = JUMP_VELOCITY;
    }
    
    public void jump() {
        yVel = JUMP_VELOCITY;
    }
    
    public void impartLeftVelocity() {
        xVel += -HORIZONTAL_MOVE;
    }
    
    public void impartRightVelocity() {
        xVel += HORIZONTAL_MOVE;
    }
    
    public void draw(double yOffset) {
        PennDraw.setPenColor(100, 200, 50);
        PennDraw.filledRectangle(xPos, yPos - yOffset, WIDTH / 2, HEIGHT / 2);
    }
    
    public void update() {
        yPos += yVel;
        xPos += xVel;
        yVel -= GRAVITY;
    }
    
    public double getX() {
        return xPos;
    }
    
    public double getY() {
        return yPos;
    }
    
    public double getYVel() {
        return yVel;
    }
    
    public static void main(String[] args) {
        Doodle d = new Doodle(0.5, 0.5);
        PennDraw.enableAnimation(60);
        while(true) {
            PennDraw.clear();
            d.draw(0);
            d.update();
            if(PennDraw.hasNextKeyTyped()) {
                char c = PennDraw.nextKeyTyped();
                if(c == ' ') {
                    d.jump();
                } else if (c == 'a') {
                    d.impartLeftVelocity();
                } else if (c == 'd') {
                    d.impartRightVelocity();
                } 
            }
            PennDraw.advance();
        }
    }
    
}
