/*
 * World
 Doodle d
 Platform[]
 Enemy[]
 isGameOver()
 draw()
 update(user input)
 */


public class DoodleWorld {
    private Doodle doodle;
    private Platform[] platforms;
    private double yOffset = 0;
    // TODO: Add enemies
    
    public DoodleWorld(int numPlatforms) {
        doodle = new Doodle(0.5, 0.25);
        platforms = new Platform[numPlatforms];
        double y = 0;
        for(int i = 0; i < numPlatforms; ++i) {
            platforms[i] = new StationaryPlatform(StdRandom.uniform(0.2, 0.8),
                                                  y*StdRandom.uniform(0.85, 1.1));
            y += 1.0 / numPlatforms;
        }
    }
    
    public boolean isGameOver() {
        return doodle.getY() < yOffset;
    }
    
    public void draw() {
        doodle.draw(yOffset);
        for(Platform p : platforms) {
            p.draw(yOffset);
        }
        PennDraw.setPenColor(PennDraw.RED);
        PennDraw.setPenRadius(0.01);
        PennDraw.line(0, 0, 1, 0);
    }
    
    public void update() {
        // update doodle
        doodle.update();
        // update all platforms and check for collisions
        for (Platform p : platforms) {
            p.update();
            if (p.collision(doodle)) {
                doodle.jump();
            }
        }
        // scroll the world up
        //yOffset += 0.003;
        // scroll the world up more according to Doodle's yVelocity
        if (doodle.getYVel() > 0) {
            yOffset += doodle.getYVel()/2;
        }
        
        // regenerate platforms that are offscreen
        for (int i = 0; i < platforms.length; i++) {
            if (yOffset > platforms[i].getY() + platforms[i].getHeight()/2) {
                platforms[i] = new StationaryPlatform(
                                      StdRandom.uniform(0.2, 0.8),
                                      yOffset + StdRandom.uniform(1.1, 1.3));
            }
        }
        
        // control Doodle left/right
        if(PennDraw.hasNextKeyTyped()) {
            char c = PennDraw.nextKeyTyped();
            if (c == 'a') {
                doodle.impartLeftVelocity();
            } else if (c == 'd') {
                doodle.impartRightVelocity();
            }
        }
    }
    
    public static void main(String[] args) {
        DoodleWorld w = new DoodleWorld(7);
        PennDraw.enableAnimation(60);
        while(true) {
            PennDraw.clear();
            w.update();
            w.draw();
            
            if (w.isGameOver()) {
                break;
            }
            
            PennDraw.advance();
        }
    }
    
}
