/** Interface for all Platforms in the DoodleJump game
  * Author: Eric Eaton
  * Date: 10/30/2019
  */
public interface Platform {
    
    /** Draw the platform onscreen
      * @param yOffset the y coordinate of the bottom of the window
      */
    public void draw(double yOffset);
    
    /** Handles motion, if any, of the platform
      */
    public void update();
    
    /** Detects whether or not Doodle collides with the top of the platform
      * @param d - Doodle
      * @return whether or not Doodle collided with the top of the platform
      */
    public boolean collision(Doodle d); // todo uncomment
    
    /** Getter for the platform's y coordinate
      * @return the platform's y coordinate
      */
    public double getY();
    
    /** Getter for the platform's height
      * @return the platform's height
      */
    public double getHeight();
}