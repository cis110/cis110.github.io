
public class World {
    private Dino dinosaur;
    private Obstacle[] obstacles;
    
    public World() {
        dinosaur = new Dino(0.1);
        obstacles = new Obstacle[3];
        for(int i = 0; i < obstacles.length; ++i) {
            obstacles[i] = new Cactus(StdRandom.uniform(1.5, 1.9), 
                                      0.2, StdRandom.uniform(0.05, 0.2));}
    }
    
    public boolean anyCollisions() {
        for (Obstacle o : obstacles) {
            // skip null obstacles
            if (o == null) continue;
            if (o.collision(dinosaur)) {
                return true;
            }
        }
        return false;
    }
    
    public void update() {
        // Keep scrolling to the right
        // todo Increase dino speed?         
        
        // Update dino and obstacles
        dinosaur.update();
        if(PennDraw.hasNextKeyTyped()) {
            PennDraw.nextKeyTyped();
            dinosaur.jump();
        }
        
        for(int i = 0; i < obstacles.length; i++) {
            Obstacle o = obstacles[i];
            // skip null obstacles
            if (o == null) continue;
            // update the obstacle's position
            o.update();
            // test if object is offscreen and delete if it is
            if (o.getX() < -1) { // obstacle is really realy offscreen
                obstacles[i] = null;
            }
            
        }
        
        
        // Generate new obstacles
        // loop thorough the obstacles array
        for(int i = 0; i < obstacles.length; i++) {
            // if obstacle is null, regenerate it with some probability
            if (obstacles[i] == null && Math.random() < 0.008) {
                obstacles[i] = new Cactus(StdRandom.uniform(1.5, 1.9), 
                                          0.2, StdRandom.uniform(0.05, 0.2));
            }
        }
        
        
        // todo Increase score
    }
    
    public void draw() {
        PennDraw.clear();
        dinosaur.draw();
        for(Obstacle o : obstacles) {
            // skip null obstacles
            if (o == null) continue;
            o.draw();
        }
    }
    
    public static void main(String[] args) {
        World w = new World();
        w.dinosaur.draw();
        for(Obstacle o : w.obstacles) {
            o.draw();
        }
    }
    
}
