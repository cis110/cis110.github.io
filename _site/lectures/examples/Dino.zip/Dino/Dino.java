public class Dino {
    
    // fields
    private double x;
    private double y;
    private double dy;
    private double width;
    private double height;
    private double gravity;
    
    // tunable parameters of the Dino
    private final double JUMP_VELOCITY = 0.03;
    
    
    /** Constructor
      * @param x - the x coordinate of the dino
      */
    public Dino(double x) {
        this.x = x;
        height = 0.2;
        width = 0.1;
        y = height/2;
        dy = 0;
        gravity = -0.001;
    }
    
    /** Draws the dino onscreen
      */
    public void draw() {
        PennDraw.setPenColor(0, 150, 0);
        PennDraw.filledRectangle(x, y, width/2, height/2);
    }
    
    public void update() {
        // use equations of motion to simulate a jump
        y += dy;
        dy += gravity;
        // if we're back on the ground, stay there
        if (y <= height/2) {
            y = height/2;
            dy = 0;
        }
    }
    
    public void jump() {
        // impart some initial y velocity if on ground
        if (y <= height/2) { // if dino is on ground
            dy = JUMP_VELOCITY;
        }
    }
    
    public void duck() {
        // todo
    }
    
    public double getX() {
        return x;
    }
    
    public double getY() {
        return y;
    }
    
    public double getWidth() {
        return width;
    }
    
    public double getHeight() {
        return height;
    }
    
    public static void main(String[] args) {
        PennDraw.setCanvasSize(500, 500);
        PennDraw.enableAnimation(30);
        
        Dino d = new Dino(0.25);
        while (true) {
            PennDraw.clear(PennDraw.WHITE);
            d.draw();
            d.update();
            if (PennDraw.hasNextKeyTyped()) {
                char c = PennDraw.nextKeyTyped();
                d.jump();
            }
            PennDraw.advance();
        }
    }
}