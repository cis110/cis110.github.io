
public class Cactus implements Obstacle {
    private double height, width;
    private double xPos;
    
    public static void main(String[] args) {
        Cactus c = new Cactus(0.5, 0.1, 0.2);
        c.draw();
    }
    
    public Cactus(double xPos, double height, double width) {
        // todo error check args
        this.height = height;
        this.width = width;
        this.xPos = xPos;
    }
    
    /** Getter for the x position of the Obstacle
      */
    @Override
    public double getX() {
        return xPos;
    }
    
    /** Draw the obstacle on screen
      */
    @Override
    public void draw() {
        PennDraw.setPenColor(0, 0, 0);
        PennDraw.filledRectangle(xPos, height / 2, width / 2, height / 2);
    }
    
    /** Handle the obstacle's motion across the screen
      */
    @Override
    public void update() {
        // TODO: Have update take in a speed
        xPos -= 0.01;
    }
    
    /** Check if the obstacle has collided with the given dino
      * @param d - the dino
      * @return whether or not there has been a collision
      */
    @Override
    public boolean collision(Dino d) {
        // Horizontal overlap test
        // Horizontal distance b/t center of dino and cactus
        double xDist = Math.abs(xPos - d.getX());
        boolean xOverlap = xDist <= (this.width / 2.0 + d.getWidth() / 2.0);
        // quick reject if does not overlap in x
        if (!xOverlap) return false;
        // check for y overlap
        double yDist = Math.abs(height / 2 - d.getY());
        boolean yOverlap = yDist <= (this.height / 2.0 + d.getHeight() / 2.0);
        return yOverlap;
    }
    
}
