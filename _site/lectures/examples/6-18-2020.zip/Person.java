

public class Person {
    // public: Can be accessed by any class
    // private: Cannot be accessed by a class outside the class in which it is
    // declared, but CAN be accessed by its declaring class.
    // Instance variables are NOT static.
    private String name;
    private int age;
    
    // Static variables declared within a class are NOT specific to any instance
    // of that class.
    // All instances of the Person class can access this variable, and an instance
    // of the Person class is NOT needed to access it from a static scope.
    // Were this variable public, then any scope (including other classes)
    // could access it by saying Person.numPeopleInExistence
    private static int numPeopleInExistence;
    
    // Java will implicitly put "this." in front of variables within functions
    // if it can't find those variables declared within the function.
    // If it also can't find variables with those names after prepending "this.",
    // then it gives a compiler error.
    // It is better style to always use "this" when referring to instance variables
    public Person() {
        name = "Bob";
        age = 50;
        ++numPeopleInExistence;
    }
    // p.sayHi() means enter the scope of sayHi(), and set "this"
    // to point to the same Person that p points to
    public void sayHi() {
        System.out.println(this.name + " says hi.");
    }
    
    public Person(String name, int age) {
        this.name = name;
        this.age = age;
        ++numPeopleInExistence;
    }
    
    // Any function declared within a class is able to see ALL functions
    // and ALL variables declared directly within that class's scope.
    
    // Because main is a STATIC function, it has no "this"
    // static means there is NO "this" within its scope
    public static void main(String[] args) {
        System.out.println("Num people: " + Person.numPeopleInExistence);
        Person a = new Person();
        System.out.println("Num people: " + Person.numPeopleInExistence);
        Person p = new Person(a.name, 60);
        System.out.println("Num people: " + Person.numPeopleInExistence);
        p.sayHi();
        a.sayHi();
        // Name is specific to Person instances, not the class itself
//        System.out.println(Person.name);
        
        final int x = 10;
        
        // . dereferences: Attempts to read the Object to which the reference points
        // If a reference is null, there is no Object to read so we get a NullPointerException
        System.out.println(p.name + "'s name is " + p.name.length() + " characters long.");
    }
    
    // Accessor function (public, returns value of private age variable)
    public int getAge() {
        return this.age;
    }
    
    // Mutator function (note the public declaration & change of age's value)
//    public void incrementAge() {
//        this.age = this.age + 1;
//    }
    
    // Helper function (note the private declaration)
    private void incrementAge() {
        this.age = this.age + 1;
    }
    
    public void liveOneDayOfLife() {
        // do stuff, then also:
        incrementAge();
    }
}
/*
 (A) 3 characters long
 (B) null characters long
 (C) Compiler error
 (D) Run-time error
 (E) Not sure
 */