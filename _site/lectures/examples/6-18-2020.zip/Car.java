/**
 * Auto Generated Java Class.
 */
public class Car {
    
    
    public static void main(String[] args) { 
        Person p = new Person();
        // . dereferences: Attempts to read the Object to which the reference points
        // If a reference is null, there is no Object to read so we get a NullPointerException
//        System.out.println(p.name + "'s name is " + p.name.length() + " characters long.");
//        System.out.println(Person.numPeopleInExistence);
        System.out.println(p.getAge());
    }
    
    /* ADD YOUR CODE HERE */
    
}
