/**
 * Auto Generated Java Class.
 */
public class InterfacesDemo {
    
    
    public static void main(String[] args) {
        // Good
        Shape sh = new Circle();
        Colorable col = new Circle();
        Circle cir = new Circle();
        // BAD
//        Square sq = new Circle(); // Square and Circle are sibling types, not equivalent
//        Shape sh = new Shape(); // Interfaces are abstract and cannot exist on their own
        
        // Shape and Colorable do not know about printCircumference, so we
        // cannot access that function through references to non-Circles
//        sh.printCircumference();
//        col.printCircumference();
        // May access printCircumference() through a reference to a Circle
        // or by casting a reference to a Circle supertype into a Circle
        cir.printCircumference();
        ((Circle)sh).printCircumference();
        
        // ClassCastException from incorrectly casting a Shape reference to
        // a type it does not refer to
        Shape sq = new Square();
        ((Circle)sq).printCircumference();
        
        // arrays have homogeneous content type
        Shape[] shapes = new Shape[10];
        for(int i = 0; i < 10; ++i) {
            if(i % 2 == 0) {
                shapes[i] = new Circle();
            }
            else {
                shapes[i] = new Square();
            }
        }
        
        for(Shape s : shapes) {
            s.printName();
        }
    }
    
    /* ADD YOUR CODE HERE */
    
}
