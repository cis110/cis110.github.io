
public interface Shape {
    public static final double PI = 3.14159;
    
    public double area();
    public double perimeter();
    public void draw();
//    public void printName();
}