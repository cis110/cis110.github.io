
public interface Colorable {
    public void setColor(int red, int green, int blue);
}