
public class Square implements Shape, Colorable {
    private double sideLen;
    private int red, green, blue;
    
    @Override
    public void setColor(int red, int green, int blue) {
        this.red = red;
        this.green = green;
        this.blue = blue;
    }
    
    @Override
    public double area() {
        return sideLen * sideLen;
    }
    
    @Override
    public double perimeter() {
        return sideLen * 4;
    }
    
    @Override
    public void draw() {
        PennDraw.filledSquare(0.5, 0.5, sideLen);
    }
    
    @Override
    public void printName() {
        System.out.println("Square");
    }
}