
public class Circle implements Shape, Colorable {
    private double radius;
    private int red, green, blue;
    
    // NOT @Override
    // Unique to the Circle class
    public void printCircumference() {
        System.out.println("My circumference is " + perimeter());
    }
    
    @Override
    public void setColor(int red, int green, int blue) {
        this.red = red;
        this.green = green;
        this.blue = blue;
    }
    
    @Override
    public double area() {
        return Shape.PI * radius * radius;
    }
    
    @Override
    public double perimeter() {
        return 2.0 * Shape.PI * radius;
    }
    
    @Override
    public void draw() {
        PennDraw.filledCircle(0.5, 0.5, radius);
    }
    
    @Override
    public void printName() {
        System.out.println("Circle");
    }
}
