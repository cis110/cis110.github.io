/*
    A program that draws an animation of Sonic the Hedgehog running from the left
    side of the screen to the right side in order to illustrate a usage of loops in
    Java.
*/

public class SonicRun {
    public static void main(String[] args) {
        // Sets the size of our canvas to 500x500 pixels
        PennDraw.setCanvasSize(500, 500);
        // Activates PennDraw's animation mode, which causes PennDraw to
        // wait to draw anything to the screen until advance() is called.
        // The input to this function dictates how many milliseconds in
        // real time to wait after advance() is called in order to achieve
        // a certain number of frames per second. In this instance, the
        // program will wait for 16 milliseconds in order to achieve
        // a frame rate of 60 frames per second.
        PennDraw.enableAnimation(60);

        // An implementation of our program using a FOR loop,
        // but in which the rate at which Sonic moves from left to right is
        // fixed to 1/7 of the screen per frame. This is because we use x
        // to both update the pixel art image displayed and the position
        // at which the picture is drawn on screen.

//        for(int x = 0; true; x = (x + 1) % 8) {
//            PennDraw.clear(PennDraw.WHITE);
//            PennDraw.picture(x / 7.0, 0.5, "run/run" + (x + 1) + ".png", 100, 100);
//            PennDraw.advance();
//        }
        
        // Declare two variables to be used in our loop.
        // "frame" is used to dictate which pixel art image will be displayed
        // when advance() is called. It loops from 1 to 8 so the running
        // animation repeats itself.
        int frame = 1;
        // "x" is used to dictate where the picture of Sonic will be drawn on
        // the screen, and loops within the range [0, 1)
        double x = 0;
        // We want our animation to play endlessly, so our WHILE loop's condition
        // is set to just "true", since WHILE loops only terminate when their
        // condition becomes "false".
        while(true) {
            // Fill the entire canvas with the color white. If we did not call
            // this function, then we would see "ghost" images of Sonic trailing behind him
            // as he ran since the older animation frames would not be erased.
            PennDraw.clear(PennDraw.WHITE);
            // Draw a picture of Sonic centered at the point (x, 0.5). The picture
            // that will be drawn will be one of the images in the "run" folder,
            // labeled run1.png through run8.png.
            // The last two inputs of this function resize the image to be 100x100
            // pixels on our screen.
            PennDraw.picture(x, 0.5, "run/run" + frame + ".png", 100, 100);
            // Calling advance() tells PennDraw to put its drawing onto the
            // canvas on our screen, then wait a certain number of milliseconds.
            // The number of milliseconds is dependent on the input to
            // PennDraw.enableAnimation, which we called earlier in our
            // main function.
            PennDraw.advance();
            // Increment the frame of our pixel art animation by 1, but make
            // it loop back to a value of 1 when it reaches a value of 9
            // by using the modulus operator.
            frame = (frame % 8) + 1;
            // Increment the variable used to dictate Sonic's horizontal
            // position on the screen by 0.005. Make it loop back to 0 when
            // it reaches a value of 1 so Sonic repeatedly runs from left to right. 
            x = (x + 0.005) % 1.0;

            // Some experiments to try: What happens if you change the rate at which
            // x increases? What if you change the denominator of its modulus operator?
            // What if you alter the input to PennDraw.enableAnimation?
        }
        
    }
}