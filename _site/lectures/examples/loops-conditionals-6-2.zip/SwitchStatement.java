public class SwitchStatement {
    public static void main(String[] args) {
        int first = Integer.parseInt(args[0]);
        String operation = args[1];
        int second = Integer.parseInt(args[2]);
        switch(operation) {
            case "plus": // Bookmark 1
                System.out.println(first + second);
                break;
            case "minus": // Bookmark 2
                System.out.println(first - second);
                break;
            case "times": // Bookmark 3
                System.out.println(first * second);
                break;
            case "div": // Bookmark 4
                System.out.println(first / second);
                break;
        }
    }
        
}
    
/*
 * int arg = Integer.parseInt(args[0]);
        switch(arg % 10) {
            case 0:
                System.out.println("Evenly divisble by 10");
                break;
            case 2:
                System.out.println("Remainder of 2");
                break;
            case 4:
                System.out.println("Remainder of 4");
                break;
            default:
                System.out.println("Some other remainder");
                break;
        }
        
        int remainder = arg % 10;
        if(remainder == 0) {
            System.out.println("Evenly divisble by 10");
        }
        else if(remainder == 2) {
            System.out.println("Remainder of 2");
        }
        else if(remainder == 4) {
            System.out.println("Remainder of 4");
        }
        else {
            System.out.println("Some other remainder");
        }
    }
 */