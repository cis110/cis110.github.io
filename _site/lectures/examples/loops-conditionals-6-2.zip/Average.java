public class Average {
    // Take in up to infinitely many numbers as command-line arguments
    // and print out their average
    public static void main(String[] args) {
        int numArgs = args.length;
        System.out.println("Number of arguments: " + numArgs);
        
        // "Accumulator variable"
        double average = 0.0;
        // ++i is shorthand for i = i + 1
        // Iterate from 0 to args.length - 1
        for(int i = 0; i < args.length; ++i) {
            average = average + Double.parseDouble(args[i]);
        }
        
        average = average / args.length;
        
        System.out.println("Average is: " + average);
    }
}