public class Conditionals2 {
    public static void main(String[] args) {
        int a = Integer.parseInt(args[0]);
        if(a < 10) {
            if(a >= 0) {
                System.out.println("a is less than 10");
                System.out.println("a is between 0 and 10");
            }
        }
        
        if(a < 10 && a >= 0) {
            System.out.println("a is less than 10");
            System.out.println("a is between 0 and 10");
        }
    }
}