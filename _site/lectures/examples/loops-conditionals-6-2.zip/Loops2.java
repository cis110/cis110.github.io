public class Loops2 {
    public static void main(String[] args) {
        String as = "A";
        for(int i = 0; i < 10; ++i) {
            System.out.println(as);
            as = as + "A";
        }
    }
}