public class WednesdayDemo {
    public static void main(String[] args) {
        // 1. Loop variable initialization: int i = 0;
        // 2. Loop continuation check: i < 3, loop continues when this evaluates to *true*
        // 3. Execute loop body
        // 4. Loop variable modification: ++i, equivalent to i = i + 1
        
        int a = 0;
        for(int i = 0; i < 3; ++i) {
            int b = 0;
            ++a;
            for(int j = i; j < 3; ++j) {
                ++b;
            }
            System.out.println("b: " + b);
        }
        System.out.println("a: " + a);
        
    }
}
