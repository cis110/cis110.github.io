/* Name: Adam Mally
 * Pennkey: amally
 * 
 * Execution: java BouncingBall
 * 
 * Animate a ball bouncing within the boundaries of the PennDraw window.
 * 
 */

public class BouncingBall {
    public static void main(String[] args) {
        PennDraw.setCanvasSize(500, 500);
        double ballRadius = 0.02;
        int ballCount = 1000;
        // Position
        double[] ballPosX = new double[ballCount]; // An array is an Object type, not a Primitive type
        double[] ballPosY = new double[ballCount];
        // Velocity
        double[] ballVelX = new double[ballCount];
        double[] ballVelY = new double[ballCount];
        // Initialize the velocities and positions
        for(int i = 0; i < ballCount; ++i) {
            // Limit ball center to a radius's distance from the screen edge
            ballPosX[i] = Math.random() * (1.0 - ballRadius * 2.0) + ballRadius; // [0.1, 0.9)
            ballPosY[i] = Math.random() * (1.0 - ballRadius * 2.0) + ballRadius;
            ballVelX[i] = (Math.random() - 0.5) * 0.025; // Now initial velocity is [-0.25, 0.25)
            ballVelY[i] = (Math.random() - 0.5) * 0.025;
        }
        PennDraw.enableAnimation(30); // 30 frames per second (FPS)
        // When animation is enabled, PennDraw applies all drawing functions
        // to an offscreen canvas. When advance() is called, the offscreen
        // canvas replaces the on-screen canvas, and then PennDraw waits
        // a certain number of milliseconds to match the FPS before allowing
        // the program to continue running
        
        // [0, 1)
        int[] red = new int[ballCount];
        int[] green = new int[ballCount];
        int[] blue = new int[ballCount];
        for(int i = 0; i < ballCount; ++i) {
            red[i] = (int) (Math.random() * 255);
            green[i] = (int) (Math.random() * 255);
            blue[i] = (int) (Math.random() * 255);
        }
        
        while(true) {
            // Fill the screen with white pixels
            PennDraw.clear(255, 255, 255, 50);
            //                   x position y position radius
            for(int i = 0; i < ballCount; ++i) {
                PennDraw.setPenColor(red[i], green[i], blue[i]);
                PennDraw.filledCircle(ballPosX[i], ballPosY[i], ballRadius);
                // Update position X and Y coords with velocity components
                ballPosX[i] = ballPosX[i] + ballVelX[i];
                ballPosY[i] = ballPosY[i] + ballVelY[i];
                // Check the ball's position relative to the screen's bounds,
                // and if it's close enough to the bounds, flip the ball's X or Y
                // velocity depending on if it's by a vertical or horizontal wall
                if((ballPosY[i] - ballRadius <= 0.0 && ballVelY[i] < 0.0) ||
                   (ballPosY[i] + ballRadius >= 1.0 && ballVelY[i] > 0.0)) {
                    ballVelY[i] = ballVelY[i] * -1 + (Math.random() - 0.5) * 0.001;
                }
                if((ballPosX[i] - ballRadius <= 0.0 && ballVelX[i] < 0.0) ||
                   (ballPosX[i] + ballRadius >= 1.0 && ballVelX[i] > 0.0)) {
                    ballVelX[i] = ballVelX[i] * -1 + (Math.random() - 0.5) * 0.001;
                }
            }
            PennDraw.advance();
        }
    }
}