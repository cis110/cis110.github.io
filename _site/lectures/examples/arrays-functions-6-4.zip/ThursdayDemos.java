
public class ThursdayDemos {
    
    
    
    
    // Function name: quadratic
    // Input(s): A double named q
    // Output: A double
    
    // y = f(x)
    public static double quadratic(double q) {
        double p = q * 0.25;
        return p * p + 1;
    }
    
   
    ///////////////////
    
    // Function name: main
    // Input(s): An array of Strings named args
    // Output: None, since it returns void
    
    public static void main(String[] args) {
        PennDraw.setXscale(-10, 10);
        PennDraw.setYscale(0, 10);
        for(double x = -10; x < 10; x = x + 0.1) {
            PennDraw.filledCircle(x, quadratic(x), 0.05);
            PennDraw.square(x, quadratic(x), 0.1);
        }
    }
}
