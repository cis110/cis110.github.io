public class ArraysDemo {
    
    public static void main(String[] args) { 
        // 1. Create an array of ints with a size determined by user command-line args
        try {
            int arrayLength = Integer.parseInt(args[0]);
            if(arrayLength < 1) {
                System.out.println("Error: Invalid array length! Must be > 0.");
            }
            else {
                int[] myArray = new int[arrayLength];
                // 2. Initialize the elements of myArray to be randomly [-5, 5] NOT [-5, 5)
                for(int i = 0; i < arrayLength; ++i) {
                    // StdRandom is a Java library contained in cis110.jar (installed in hw0)
                    // It contains a variety of functions for generating random distributions
                    // of numbers, both doubles AND ints
                    myArray[i] = StdRandom.uniform(-5, 6);//(int)(Math.random() * 10.001 - 5.0); // [-5, 5]
                }
                for(int i = 0; i < arrayLength; ++i) {
                    System.out.print(myArray[i] + " ");
                }
                System.out.println();
                // 3. Find the maximum value stored in our array of the numbers generated
                // 0th element is either:
                // Case A: The max value in the array, so we've correctly init'd maxValue to its final value
                // Case B: Smaller than the max value in the array, so we'll eventually update maxValue to the
                //         actual max value somewhere in the FOR loop
                // In NEITHER case will maxValue be initialized to a value GREATER THAN the array's actual max
                int maxValue = myArray[0];
                System.out.println("maxValue is initially " + maxValue);
                for(int i = 0; i < myArray.length; ++i) {
                    if(myArray[i] > maxValue) {
                        maxValue = myArray[i];
                        System.out.println("maxValue was just updated to " + maxValue);
                    }
                }
                System.out.println("Max value is: " + maxValue);
                
                // TODO for tomorrow: Compute the average value of all ints in the array
                double sum = 0;
                for(int i = 0; i < myArray.length; ++i) {
                    sum = sum + myArray[i];
                }
                sum = sum / myArray.length;
                System.out.println("Average of array is: " + sum);
            }
        }
        catch(NumberFormatException e) {
            System.out.println("Error: Did not pass number as argument.");
        }
    }
    
}
