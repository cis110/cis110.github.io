/* Name: Adam Mally
 * Pennkey: amally
 * 
 * Execution: java BouncingBall
 * 
 * Animate a ball bouncing within the boundaries of the PennDraw window.
 * 
 */

public class BouncingBallFunctions {
    public static double ballRadius = 0.02;
    public static int ballCount = 1000;
    // Position
    public static double[] ballPosX; 
    public static double[] ballPosY;
    // Velocity
    public static double[] ballVelX;
    public static double[] ballVelY;
    //Color
    public static int[] red;
    public static int[] green;
    public static int[] blue;
    
    // USELESS FUNCTION! These variables will only be accessible to the scope of
    // declareVariables, and are removed from memory as soon as declareVariables
    // reaches its }
    public static void declareVariables() {
        double ballRadius = 0.02;
        int ballCount = 1000;
        // Position
        double[] ballPosX; 
        double[] ballPosY;
        // Velocity
        double[] ballVelX;
        double[] ballVelY;
        //Color
        int[] red;
        int[] green;
        int[] blue;
    }
    
    // void return type just means the function has no return value
    // It does NOT mean it has no effect on anything in the program
    public static void createBallArrays() {
        ballPosX = new double[ballCount];
        ballPosY = new double[ballCount];
        
        ballVelX = new double[ballCount];
        ballVelY = new double[ballCount];
        
        red = new int[ballCount];
        green = new int[ballCount];
        blue = new int[ballCount];
    }
    
    public static void main(String[] args) {
        PennDraw.setCanvasSize(500, 500);
        
        createBallArrays();
        initBallPosAndVelAndColor();
        
        PennDraw.enableAnimation(30); // 30 frames per second (FPS)
        // When animation is enabled, PennDraw applies all drawing functions
        // to an offscreen canvas. When advance() is called, the offscreen
        // canvas replaces the on-screen canvas, and then PennDraw waits
        // a certain number of milliseconds to match the FPS before allowing
        // the program to continue running
        
        while(true) {
            // Fill the screen with white pixels
            PennDraw.clear(255, 255, 255, 50);
            //                   x position y position radius
            for(int i = 0; i < ballCount; ++i) {
                drawBall(i);
                updateBallPos(i);
                checkBallBounce(i);
            }
            PennDraw.advance();
        }
    }
    
    public static void initBallPosAndVelAndColor() {
        // Initialize the velocities and positions
        for(int i = 0; i < ballCount; ++i) {
            // Limit ball center to a radius's distance from the screen edge
            ballPosX[i] = Math.random() * (1.0 - ballRadius * 2.0) + ballRadius; // [0.1, 0.9)
            ballPosY[i] = Math.random() * (1.0 - ballRadius * 2.0) + ballRadius;
            
            ballVelX[i] = (Math.random() - 0.5) * 0.025; // Now initial velocity is [-0.25, 0.25)
            ballVelY[i] = (Math.random() - 0.5) * 0.025;
            
            red[i] = (int) (Math.random() * 255);
            green[i] = (int) (Math.random() * 255);
            blue[i] = (int) (Math.random() * 255);
        }
    }
    
    public static void drawBall(int i) {
        PennDraw.setPenColor(red[i], green[i], blue[i]);
        PennDraw.filledCircle(ballPosX[i], ballPosY[i], ballRadius);
    }
    
    public static void updateBallPos(int i) {
        // Update position X and Y coords with velocity components
        ballPosX[i] = ballPosX[i] + ballVelX[i];
        ballPosY[i] = ballPosY[i] + ballVelY[i];
    }
    
    public static void checkBallBounce(int i) {
        // Check the ball's position relative to the screen's bounds,
        // and if it's close enough to the bounds, flip the ball's X or Y
        // velocity depending on if it's by a vertical or horizontal wall
        if((ballPosY[i] - ballRadius <= 0.0 && ballVelY[i] < 0.0) ||
           (ballPosY[i] + ballRadius >= 1.0 && ballVelY[i] > 0.0)) {
            ballVelY[i] = ballVelY[i] * -1 + (Math.random() - 0.5) * 0.001;
        }
        if((ballPosX[i] - ballRadius <= 0.0 && ballVelX[i] < 0.0) ||
           (ballPosX[i] + ballRadius >= 1.0 && ballVelX[i] > 0.0)) {
            ballVelX[i] = ballVelX[i] * -1 + (Math.random() - 0.5) * 0.001;
        }
    }
    
    
}