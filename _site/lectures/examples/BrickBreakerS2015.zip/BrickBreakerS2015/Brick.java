import java.awt.Color;

public class Brick {
  public static final double WIDTH = 0.1;
  public static final double HEIGHT = 0.05;
  
  private double x;
  private double y;
  private Color color;
  
  public Brick(double x, double y) {
    this.x = x;
    this.y = y;
    color = new Color((float) Math.random(), 
                      (float) Math.random(), 
                      (float) Math.random());
  }
  
  public void display() {
    StdDraw.setPenColor(color);
    StdDraw.filledRectangle(x, y, WIDTH, HEIGHT);
  }
  
  //boolean collision(Ball b)
  // - break brick // save for later
}