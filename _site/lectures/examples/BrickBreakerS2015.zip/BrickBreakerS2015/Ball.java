public class Ball {
  
  private static final double RADIUS = 0.01;
  
  private double x;
  private double y;
  private double dx;
  private double dy;
  
  public Ball(double x, double y, 
              double initialXVelocity, 
              double initialYVelocity) {
    this.x = x;
    this.y = y;
    this.dx = initialXVelocity;
    this.dy = initialYVelocity;
  }
  
  public void display() {
    StdDraw.setPenColor(StdDraw.RED);
    StdDraw.filledCircle(x, y, RADIUS);
  }
  
  public void move() {
    y += dy;
    x += dx;
  }
  
  public void bounceHorizontal() {
    dx = -dx;
  }
  
  public void bounceVertical() {
    dy = -dy;
  }
  
  public void impartHorizontalVelocity(double dx) {
    this.dx += dx;
  }
  
  
  public double getX() { return x; }
  public double getY() { return y; }
  public double getRadius() { return RADIUS; }
}