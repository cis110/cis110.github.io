public class BrickBreakerS2015 {
  
  private final static double PADDLE_DAMPING_FACTOR = 0.5;
  private final static double STARTING_BRICK_Y = 0.5;
  private final static double ENDING_BRICK_Y = 0.8;
  
  private static Paddle paddle = new Paddle();
  private static Ball ball = null;
  private static Brick[] bricks = null;
  
  public static void main(String[] args) {
    setup();
    while(true) {
      draw();
      StdDraw.show(20);
    }
  }
  
  public static void setup() {
    
    // compute size of bricks array
    int numRows = (int) ((ENDING_BRICK_Y - STARTING_BRICK_Y) / (2 * Brick.HEIGHT));
    int numCols = (int) ((1 - 2 * Brick.WIDTH) / (2 * Brick.WIDTH));
    System.out.println(numRows + " " + numCols);
    System.exit(1);
    bricks = new Brick[numRows * numCols];
    
    // initialize array of bricks
    int i = 0;
    for (double x = Brick.WIDTH; x < 1 - Brick.WIDTH; 
         x += 2 * Brick.WIDTH) {
      for (double y = STARTING_BRICK_Y; y < ENDING_BRICK_Y; 
           y += 2 * Brick.HEIGHT) {
         bricks[i++] = new Brick(x, y);
      }
    }
  }
  
  public static void draw() {
    StdDraw.clear(StdDraw.WHITE);

    // display all objects
    paddle.display();
    if (ball != null) {
      ball.display();
      System.out.println("Ball at: " +ball.getX() + " " + ball.getY());
    }
    for (Brick b : bricks) {
      b.display();
    }
    
    // move all objects
    paddle.move();
    if (ball != null) {
      ball.move();
    }
    
    // launch ball if ball is lost and user clicks
    if (StdDraw.mousePressed() && ball == null) {
      ball = paddle.launchBall();
      System.out.println("Ball launched: " +ball.getX() + " " + ball.getY());
    }
    
    // bounce balls off top of screen
    if (ball != null && ball.getY() >= 1) 
      ball.bounceVertical();
    
    // bounce balls off walls
    if (ball != null && 
        (ball.getX() >= 1 || ball.getX() <= 0))
      ball.bounceHorizontal();
        
    // bounce ball off paddle
    if (ball != null && paddle.isCollision(ball)) {
      ball.bounceVertical();
      ball.impartHorizontalVelocity(PADDLE_DAMPING_FACTOR * paddle.getHorizontalVelocity());
    }
          
    
    // delete balls that are off the bottom of the screen
    if (ball != null && ball.getY() <= -0.1) {
      System.out.println("Ball is now offscreen: " + ball.getX() + " " + ball.getY());
      ball = null;
    }
  }
  
  
  private static boolean isOnScreen(Ball b) {
    double buffer = 0.01;
    return (b.getX() - b.getRadius() >= 0 - buffer) &&
           (b.getX() + b.getRadius() <= 1 + buffer) &&
           (b.getY() - b.getRadius() >= 0 - buffer) &&
           (b.getY() + b.getRadius() <= 1 + buffer);
  }
}
