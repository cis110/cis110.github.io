public class Paddle {
  
  private static final double INITIAL_X_POSITION = 0.5;
  private static final double PADDLE_WIDTH = 0.1;
  private static final double PADDLE_HEIGHT = 0.01;
  
  private double x;
  private double dx = 0;
  private static final double Y = 0;


  // default constructor
  public Paddle() {
    x = INITIAL_X_POSITION;
  }
  
  // draw the paddle
  public void display() {
    StdDraw.setPenColor(StdDraw.BLACK);
    StdDraw.filledRectangle(x, Y, PADDLE_WIDTH, PADDLE_HEIGHT);
  }
  
  // update the paddle's position in response to user control
  public void move() {
    double oldX = x;
    x = StdDraw.mouseX();
    dx = x - oldX;
  }
  
  // detect collisions with the given ball
  public boolean isCollision(Ball b) {
    double bx = b.getX();
    double by = b.getY();
    // TODO fix edge case of tip of ball hitting paddle
    return (x - PADDLE_WIDTH < bx) && 
           (x + PADDLE_WIDTH > bx) &&
           (Y - PADDLE_HEIGHT < by) && 
           (Y + PADDLE_HEIGHT > by);
    
  }
  
  public double getHorizontalVelocity() {
    return dx;
  }
  
  public Ball launchBall() {
    return new Ball(x, Y+PADDLE_HEIGHT, 0, 0.01);
  }
}