
public class LinkedList implements List{
    private IntNode head; // The first node in the linked list
    
    public LinkedList() {
        this.head = null;
    }
    
    // Also talk about time complexity of Linked List operations
    
    // Append a node with the given value to the end of the linked list
    @Override
    public boolean append(int value) {
        // Handle an empty linked list as a special case
        if(head == null) {
            head = new IntNode(value);
            return true;
        }
        
        IntNode curr;
        for(curr = head; curr.next != null; curr = curr.next) {
            ;
        }
        curr.insertNext(value);
        return true;
    }
    @Override
    public int size() {
        int length = 0;
        // Do I need to specially handle the case in which start is null?
        for(IntNode curr = this.head; curr != null; curr = curr.next) {
            ++length;
        }
        return length;
    }
    
    
// Returns true if this list is empty
    @Override
    public boolean isEmpty() {
        return head == null;
    }
    // Remove all contents from the list, so it is once again empty
    @Override
    public void clear() {
        this.head = null;
    }
// Insert "it" at the position index in this list.
// throws IndexOutOfBoundsException - if the index is out of range (index < 0 || index > length)
    @Override
    public boolean insert(int index, int it) {
        // There are no indices in an empty linked list,
        // so we can't insert anything anywhere.
        if(this.head == null) {
            throw new IndexOutOfBoundsException("" + index);
        }
        // 0 is a special case because we need to replace
        // the head of the linked list with the new node,
        // and set the new node's next to the old head
        if(index == 0) {
            IntNode newNode = new IntNode(it);
            newNode.next = this.head;
            this.head = newNode;
            return true;
        }
        
        int currentIndex = 1;
        // Before we do the loop, can we check if i is out of bounds of our list?
        // No, we cannot.
        for(IntNode curr = head; curr != null; curr = curr.next) {
            if(currentIndex == index) {
                curr.insertNext(it);
                return true;
            }
            ++currentIndex;
        }
        // Do something if the index ended up being out of bounds
        throw new IndexOutOfBoundsException("" + index);
    }
// Removes and return the element at the specified position in this list
// throws IndexOutOfBoundsException - if the index is out of range (index < 0 || index >= length)
    @Override
    public int remove(int index) {
        if(this.head == null) {
            throw new IndexOutOfBoundsException("" + index);
        }
        // If we want to remove the head of our LL, it's also a special case
        if(index == 0) {
            int value = this.head.data;
            this.head = this.head.next;
            return value;
        }
        
        int currentIndex = 1;
        for(IntNode curr = this.head; curr != null; curr = curr.next) {
            if(currentIndex == index) {
                int value = curr.next.data;
                curr.removeNext();
                return value;
            }
            ++currentIndex;
        }
        throw new IndexOutOfBoundsException("" + index);
    }
// Returns the element at the specified position in this list
// throws IndexOutOfBoundsException - if the index is out of range (index < 0 || index >= length)
    @Override
    public int get(int index) {
        int currentIndex = 0;
        for(IntNode curr = this.head; curr != null; curr = curr.next) {
            if(currentIndex == index) {
                return curr.data;
            }
            ++currentIndex;
        }
        throw new IndexOutOfBoundsException("" + index);
    }
// Returns true if this list contains the specified element. False otherwise.
    @Override
    public boolean contains(int value) {
        for(IntNode curr = this.head; curr != null; curr = curr.next) {
            if(curr.data == value) {
                return true;
            }
        }
        return false;
    }
    
    public static void main(String[] args) {
        LinkedList ll = new LinkedList();
        System.out.println("Size: " + ll.size());
        ll.append(10);
        ll.append(20);
        ll.append(30);
        ll.insert(0, 12);
        ll.insert(2, 40);
        IntNode.printList(ll.head);
        System.out.println("Size: " + ll.size());
    }
}