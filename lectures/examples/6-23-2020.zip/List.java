public interface List {
// Remove all contents from the list, so it is once again empty
    public void clear();
// Insert "it" at the position index in this list.
// throws IndexOutOfBoundsException - if the index is out of range (index < 0 || index > length)
    public boolean insert(int index, int it);
// Append "it" at the end of the list
    public boolean append(int it);
// Removes and return the element at the specified position in this list
// throws IndexOutOfBoundsException - if the index is out of range (index < 0 || index >= length)
    public int remove(int index);
// Returns the element at the specified position in this list
// throws IndexOutOfBoundsException - if the index is out of range (index < 0 || index >= length)
    public int get(int index);
// Returns true if this list contains the specified element. The empty String otherwise
    public boolean contains(int o);
// Returns the length / number of elements in this list
    public int size();
// Returns true if this list is empty
    public boolean isEmpty();
}