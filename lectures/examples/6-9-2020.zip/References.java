

public class References {
    
    /* Name: twice
     * PreCondition: array is NOT null
     * PostCondition: Each element of array is now twice its old value
     * @param array: An array of ints to be doubled
     */
    public static void twice(int[] array) {
        for(int i = 0; i < array.length; ++i) {
            array[i] = array[i] * 2;
        }
    }
    // Think of all public static functions as being
    // siblings in scope. They know about each other, but
    // can't see inside each others' scope bodies
    
    public static void main(String[] args) {
        int[] arr = {1, 2, 3, 4};
        twice(arr);
        
        int[] array = arr;
        for(int i = 0; i < array.length; ++i) {
            array[i] = array[i] * 2;
        }
    }
    /*
     (A) 1, 2, 3, 4
     (B) 2, 4, 6, 8
     (C) I'm not sure
    */
    
}

/*
 * int[] a = {1, 2, 3, 4};
        int[] b = new int[a.length];
        for(int i = 0; i < a.length; ++i) {
            b[i] = a[i];
        }
        int[] c = a;
        
        System.out.println("a's value is " + a);
        System.out.println("b's value is " + b);
        System.out.println("c's value is " + c);
        
        System.out.println("a's elements:");
        
        // Just a "for" loop
        for(int i = 0; i < a.length; ++i) {
            int x = a[i];
            System.out.print(x + " ");
        }
        // "for-each" loop
        for(int x : a) {
            System.out.print(x + " ");
        }
        System.out.println();
        System.out.println("b's elements:");
        for(int x : b) {
            System.out.print(x + " ");
        }
        System.out.println();
        
        System.out.println("a == b is " + (a == b));
        System.out.println("a == c is " + (a == c));
 */