
public class Recursion {
    
    public static void main(String[] args) { 
        int[] arr = {2, 3, 4, 5};
        System.out.println("Does arr contain odd number? " + isAnyOdd(arr));
    }
    
    /*
     *  Purpose: Tell us whether any element in arr is an odd integer
     */
    // 1) Let's do this with a loop (ITERATIVELY)
    // { 2, 3, 4, 5 }
    public static boolean isAnyOdd(int[] arr) {
        for(int i = 0; i < arr.length; ++i) {
            if(arr[i] % 2 == 1) {
                return true;
            }
        }
        return false;
    }
    // 2) Let's do this RECURSIVELY
    public static boolean isAnyOdd(int[] arr, int currentIndex) {
        if(currentIndex == arr.length) {
            return false;
        }
        if(arr[currentIndex] % 2 == 1) {
            return true;
        }
        return isAnyOdd(arr, currentIndex + 1);
    }
    
    // A function that is recursive invokes itself from within its own body
    public static void countdown(int x) {
        System.out.println("Before recursion: " + x);
        if(x > 0) {
            countdown(x - 1);
        }
        System.out.println("After recursion: " + x);
    }
    
    
    
//    System.out.println("Before recursion: " + x);
//    if(x > 0) {
//        System.out.println("Before recursion: " + x - 1);
//        if(x - 1 > 0) {
//            System.out.println("Before recursion: " + x - 2);
//            if(x - 2 > 0) {
//                System.out.println("Before recursion: " + x - 3);
//                if(x - 3 > 0) {
//                    //countdown(x - 1); Doesn't happen b/c if is false
//                }
//                System.out.println("After recursion: " + x - 3);
//            }
//            System.out.println("After recursion: " + x - 2);
//        }
//        System.out.println("After recursion: " + x - 1);
//    }
//    System.out.println("After recursion: " + x);
    
}
