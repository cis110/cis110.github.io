//-------------------------------------------------------------------------
/**
 * The Bag interface defines the operations on a bag collection. Our bag will
 * contain Book objects
 *
 */
public interface Bag {
    // ----------------------------------------------------------
    /**
     * Adds the specified element to the bag.
     *
     * @param book Book to be added
     * @precondition parameter book is not null
     */
    public void add(Book book);

    // ----------------------------------------------------------
    /**
     * Removes and returns the specified book from the bag. If multiple copies of
     * the same book appear in the bag, only one is removed.
     *
     * @param target item to be removed
     * @return the item removed or null if not found
     * @precondition parameter target is not null
     * @postcondition returned value x.equals(target)
     */
    public Book remove(Book target);

    // ----------------------------------------------------------
    /**
     * Removes and returns a random Book from the bag.
     *
     * @return the element removed or null if the bag is empty
     */
    public Book removeRandom();

    // ----------------------------------------------------------
    /**
     * Determines if the bag contains the specified book.
     *
     * @param target book to be found
     * @return true if target is in the collection, false otherwise
     * @precondition parameter target is not null
     */
    public boolean contains(Book target);

    // ----------------------------------------------------------
    /**
     * Determines if the bag contains no elements.
     *
     * @return true if collection is empty, false otherwise
     */
    public boolean isEmpty();

    // ----------------------------------------------------------
    /**
     * Determines the number of elements currently in the bag.
     *
     * @return the number of elements in the bag
     */
    public int size();

    // ----------------------------------------------------------
    /**
     * Returns a string representation of this bag. A bag's string representation is
     * written as a comma-separated list of its contents (in some arbitrary order)
     * surrounded by curly braces, like this:
     * 
     * <pre>
     * { book1, book2, book3, book4, book5 }
     * </pre>
     * <p>
     * An empty bag is simply {}.
     * </p>
     *
     * @return a string representation of the bag and its contents
     */
    public String toString();
}
