import static org.junit.Assert.fail;
import org.junit.Test;

//-------------------------------------------------------------------------
/**
 * Tests for the {@link ListBasedBag} class.
 *
 * @author Partner 1's name (pid)
 * @version (place the date here, in this format: yyyy.mm.dd)
 */
public class ListBasedBagTest {
    // ~ Instance/static variables .............................................

    // ~ Constructor ...........................................................

    // ----------------------------------------------------------
    // ----------------------------------------------------------
    /**
     * Test method for {@link ListBasedBag#add(java.lang.Object)}.
     */
    @Test
    public void testAdd() {
        fail("Not yet implemented");
    }

    // ----------------------------------------------------------
    /**
     * Test method for {@link ListBasedBag#remove(java.lang.Object)}.
     */
    @Test
    public void testRemove() {
        fail("Not yet implemented");
    }

    // ----------------------------------------------------------
    /**
     * Test method for {@link ListBasedBag#removeRandom()}.
     */
    @Test
    public void testRemoveRandom() {
        fail("Not yet implemented");
    }

    // ----------------------------------------------------------
    /**
     * Test method for {@link ListBasedBag#contains(java.lang.Object)}.
     */
    @Test
    public void testContains() {
        fail("Not yet implemented");
    }

    // ----------------------------------------------------------
    /**
     * Test method for {@link ListBasedBag#isEmpty()}.
     */
    @Test
    public void testIsEmpty() {
        fail("Not yet implemented");
    }

    // ----------------------------------------------------------
    /**
     * Test method for {@link ListBasedBag#size()}.
     */
    @Test
    public void testSize() {
        fail("Not yet implemented");
    }

    // ----------------------------------------------------------
    /**
     * Test method for {@link ListBasedBag#toString()}.
     */
    @Test
    public void testToString() {
        fail("Not yet implemented");
    }

}
