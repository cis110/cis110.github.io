//-------------------------------------------------------------------------
/**
 * This class represents an implementation of a bag collection that internally
 * uses an ArrayList or a LinkedList to hold the items.
 *
 * We will complete this class.
 *
 * 
 */
public class ListBasedBag implements Bag {

    // You write the declaration for this field:
    // private ???????? contents; // the bag contents

    // ~ Constructors ..........................................................

    // ----------------------------------------------------------
    /**
     * Creates an empty bag using the default capacity.
     */
    public ListBasedBag() {
        // TODO
    }

    // ----------------------------------------------------------
    /**
     * Creates an empty bag using the specified capacity.
     * 
     * @param initialCapacity
     */
    public ListBasedBag(int initialCapacity) {
        // TODO: create an ArrayList to hold your contents, and set your
        // contents field to refer to this new object. Be sure to create
        // the ArrayList with the specified capacity.
    }

    @Override
    public void add(Book book) {
        // TODO Auto-generated method stub

    }

    @Override
    public Book remove(Book target) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Book removeRandom() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public boolean contains(Book target) {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public boolean isEmpty() {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public int size() {
        // TODO Auto-generated method stub
        return 0;
    }
}
