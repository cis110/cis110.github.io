/**
 * Auto Generated Java Class.
 */
public class Pet {
    // Non-static variables declared directly in a class's scope
    // are known as Instance Variables for that class
    public String name;
    public String species;
    public double age;
    public String healthStatus;
    
    // NOTE: This does NOT use the static keyword!
    public void printInfo() {
        System.out.print(this.name + "'s info: " + "\nSpecies: "
                             + this.species + "\nAge: " + this.age
                             + "\nHealth status: " + this.healthStatus + "\n");
    }
    
    // Constructor for our class
    /*May have arguments, may have none. Up to you.*/
//    public Pet() {
//        this.name = "Anonymous";
//        this.species = "UNKNOWN";
//        this.age = -1;
//        this.healthStatus = "UNKNOWN";
//    }
    
    public Pet(String name) {
        ;
    }
    
    public Pet(String name, String species, double age, String healthStatus) {
//        name = name; // both names refer to the variable that is passed into this function
        this.name = name; // this.name refers to the instance variable, and name refers to the function argument
        this.species = species;
        this.age = age;
        this.healthStatus = healthStatus;
    }
}
