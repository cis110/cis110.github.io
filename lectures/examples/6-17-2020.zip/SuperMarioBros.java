/**
 * Auto Generated Java Class.
 */
public class SuperMarioBros {
    
    
    public static void main(String[] args) { 
        Mario m = new Mario();
        // Illegal since posX and posY are private
//        m.posX = 1.0;
//        m.posY = 2.0;
        boolean gameOver = false;
        while(!gameOver) {
            m.updatePos(0.1);
//            m.posX = m.posY + 1;
        }
    }
    
    /* ADD YOUR CODE HERE */
    
}
