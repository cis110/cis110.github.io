
// If we allow Java to default-construct a Ball, all its instance variables
// will be default-initialized to 0.0 or 0 respectively.
public class Ball {
    public double posX, posY;
    public double velX, velY;
    public int red, green, blue;
    public double radius;
    
    public void print() {
        System.out.println("Pos: " + posX + ", " + posY);
        System.out.println("Vel: " + velX + ", " + velY);
        System.out.println("Color: " + red + ", " + green + ", " + blue);
        System.out.println();
    }
    
    public void draw() {
        PennDraw.setPenColor(red, green, blue);
        PennDraw.filledCircle(posX, posY, radius);
    }
    
    public void updatePos() {
        posX = posX + velX;
        posY = posY + velY;
    }
    
    public void checkBounce() {
        if((posY - radius <= 0.0 && velY < 0.0) ||
           (posY + radius >= 1.0 && velY > 0.0)) {
            velY = velY * -1 + (Math.random() - 0.5) * 0.001;
        }
        if((posX - radius <= 0.0 && velX < 0.0) ||
           (posX + radius >= 1.0 && velX > 0.0)) {
            velX = velX * -1 + (Math.random() - 0.5) * 0.001;
        }
    }
    
    // Argumentless constructor
    public Ball() {
        radius = 0.02;
        
        posX = Math.random() * (1.0 - radius * 2.0) + radius;
        posY = Math.random() * (1.0 - radius * 2.0) + radius;
        
        velX = (Math.random() - 0.5) * 0.025;
        velY = (Math.random() - 0.5) * 0.025;
        
        red = (int) (Math.random() * 255);
        green = (int) (Math.random() * 255);
        blue = (int) (Math.random() * 255);
    }
}
