/* Name: Adam Mally
 * Pennkey: amally
 * 
 * Execution: java BouncingBallObj
 * 
 * Animate a ball bouncing within the boundaries of the PennDraw window.
 * 
 */

public class BouncingBallObj {
    
    public static void main(String[] args) { 
        int ballCount = Integer.parseInt(args[0]);
        // This allocates an *array* of Ball *references*
        Ball[] balls = new Ball[ballCount];
        // TODO instantiate each ball in the array
        for(int i = 0; i < ballCount; ++i) {
            balls[i] = new Ball();
        }
        
        PennDraw.enableAnimation(30); // 30 frames per second (FPS)
        
        while(true) {
            // Fill the screen with white pixels
            PennDraw.clear(255, 255, 255, 50);
            
            for(int i = 0; i < ballCount; ++i) {
                balls[i].draw();
                balls[i].updatePos();
                balls[i].checkBounce();
            }
            PennDraw.advance();
        }
    }
    
    
}
