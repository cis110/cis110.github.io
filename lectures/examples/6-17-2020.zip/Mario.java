
// public: the variable or function is part of the "interface" of my program
//    Exposes that var/func to other classes in my program
// private: the variable or function is part of the "implementation" of my program
//    Prevents any other class from even seeing the var/func in question

public class Mario {
    private double posX, posY;
    private double velX, velY;
    // I only want Mario's position to be changed by his velocity * change_in_time
    // I don't want my teammate to be able to directly manipulate Mario's position
    // I want Mario's position to be part of the "implementation" portion of my code
    
    public Mario() {
        posX = 10;
        posY = 0;
        velX = 1;
        velY = 1;
    }
    
    public void updatePos(double deltaTime) {
        posX += velX * deltaTime;
        posY += velY * deltaTime;
    }
}

//public class Goomba{}
//
//public class Ground{}
//
//etc.