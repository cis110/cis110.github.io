import static org.junit.Assert.*;
import org.junit.Test;

public class GameTests {

    @Test
    public void testDinoJumpGivesPositiveVelocity() {
        Dino d = new Dino(0.4);
        d.jump();

        assertTrue(d.getdy() > 0);
    }

    @Test
    public void testDinoJumpVelocityDecays() {
        Dino d = new Dino(0.4);
        d.jump();
        double oldVel = d.getdy();
        for (int i = 0; i < 5; i++) {
            d.update();
        }
        double newVel = d.getdy();

        assertTrue(oldVel > newVel);
    }

}
