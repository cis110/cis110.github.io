
public class World {
    private Dino dinosaur;
    private Obstacle[] obstacles;
    private int score;

    /**
     * Initializes the dinosaur, the array to store the obstacles, and make sure the
     * score starts at 0.
     */
    public World() {
        return;
    }

    /**
     * Checks all obstacles to see if they collide with the dinosaur.
     * 
     * @return true when dinosaur collides with at least one obstacle, else false
     */
    public boolean anyCollisions() {
        return false;
    }

    /**
     * Passing a single timestep, the world should move the dinosaur, move the
     * obstacles, check for any collisions, increment the score, and generate new
     * obstacles as necessary.
     */
    public void update() {
        return;
    }

    /**
     * Draw the score, the dinosaur, and the obstacles. Could additionally draw a
     * floor and background for presentation purposes.
     */
    public void draw() {
        return;
    }

}
