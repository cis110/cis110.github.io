
public class Game {

    public static void main(String[] args) {
        World world = new World();
        PennDraw.enableAnimation(60);
        // TODO: Change condition to be based
        // on game-lose case
        while (true) {
            world.update();
            world.draw();

            if (world.anyCollisions()) {
                PennDraw.disableAnimation();
                break;
            }

            PennDraw.advance();
        }
    }

}
