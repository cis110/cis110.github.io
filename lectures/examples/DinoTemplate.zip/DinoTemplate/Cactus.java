
public class Cactus implements Obstacle {
  private double height, width;
  private double xPos;

  /**
   *
   * @param xPos   the starting x coordinate of the cactus
   * @param height the height of the cactus
   * @param width  the width of the cactus
   */
  public Cactus(double xPos, double height, double width) {
    return;
  }

  /**
   * Getter for the x position of the Obstacle (you can have this one for free)
   */
  @Override
  public double getX() {
    return xPos;
  }

  /**
   * Draw the obstacle on screen
   */
  @Override
  public void draw() {
    return;
  }

  /**
   * Handle the obstacle's motion across the screen
   */
  @Override
  public void update() {
    return;
  }

  /**
   * Check if the obstacle has collided with the given dino A collision between
   * two rectangles can be determined using the distances between their centers in
   * both dimensions
   * 
   * @param d - the dino
   * @return whether or not there has been a collision
   */
  @Override
  public boolean collision(Dino d) {
    return false;
  }

}
