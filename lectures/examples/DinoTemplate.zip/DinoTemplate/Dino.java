public class Dino {

    // fields
    private double x;
    private double y;
    private double dy;
    private double width;
    private double height;
    private double gravity;

    // tunable parameters of the Dino
    private final double JUMP_VELOCITY = 0.03;

    /**
     * Constructor
     * 
     * @param x - the x coordinate of the dino
     */
    public Dino(double x) {
        return;
    }

    /**
     * Draws the dino onscreen
     */
    public void draw() {
        return;
    }

    /**
     * Allow for a jump to start if on the ground, otherwise carry out the jump as
     * usual
     */
    public void update() {
        return;
    }

    public void jump() {
        return;
    }

    public void duck() {
        // todo
    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    public double getdy() {
        return y;
    }

    public double getWidth() {
        return width;
    }

    public double getHeight() {
        return height;
    }
}