public class Pterodactyl implements Obstacle {

    private double height, width;
    private double xPos, yPos;

    /**
     *
     * @param xPos   the starting x coordinate of the pterodactyl
     * @param yPos   the starting x coordinate of the pterodactyl
     * @param height the height of the pterodactyl
     * @param width  the width of the pterodactyl
     */
    public Pterodactyl(double xPos, double yPos, double height, double width) {
        return;
    }

    /**
     * Getter for the x position of the Obstacle (you can have this one for free)
     */
    @Override
    public double getX() {
        return xPos;
    }

    /**
     * Getter for the x position of the Pterodactyl (you can have this one for free)
     */
    public double getY() {
        return xPos;
    }

    /**
     * Draw the obstacle on screen
     */
    @Override
    public void draw() {
        return;
    }

    /**
     * Handle the obstacle's motion across the screen
     */
    @Override
    public void update() {
        return;
    }

    /**
     * Check if the obstacle has collided with the given dino. A collision between
     * two rectangles can be determined using the distances between their centers in
     * both dimensions
     * 
     * @param d - the dino
     * @return whether or not there has been a collision
     */
    @Override
    public boolean collision(Dino d) {
        return false;
    }

}
