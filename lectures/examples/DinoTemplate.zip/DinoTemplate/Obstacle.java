/**
 * The interface for all obstacles in the Dino game
 * 
 * Original Author: Eric Eaton
 * 
 * Revised by: Harry Smith, 12/8/2020
 */
public interface Obstacle {

  /**
   * Draw the obstacle on screen
   */
  public void draw();

  /**
   * Handle the obstacle's motion across the screen
   */
  public void update();

  /**
   * Getter for the x position of the Obstacle
   */
  public double getX();

  /**
   * Check if the obstacle has collided with the given dino
   * 
   * @param d - the dino
   * @return whether or not there has been a collision
   */
  public boolean collision(Dino d);

}