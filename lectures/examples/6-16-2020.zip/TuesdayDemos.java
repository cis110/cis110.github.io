//
//// AF 0
//main() {
//    print(83/*f(2)*/);
//}
//// END AF 0
//
//// AF 1
//f(y <- 2) {
//    if(y == 1) (this is false);
//    else {
//        5;/*f(1);*/ // Spawns AF 2
//        y = y + 1; // now y is 3 in this activation frame
//        return 83;
//    }
//}
//// END AF 1
//
//// AF 2, also knows where in the program it was spawned from
//f(y <- 1) {
//    if(y == 1) (this is true) {
//        return 5;
//    }
//}
// END AF 2



public class TuesdayDemos {
    
//What will be printed in main when f(2) is executed?
    public static int f(int y) {
        if(y == 1) {
            return 5;
        }
        else {
            f(y - 1);
            y = y + 1;
            return 83;
        }
    }
    
    public static void main(String[] args) {
        System.out.println(f(2));
    }
    /*
     (A) 5
     (B) 83
     (C) 583
     (D) 835
     (E) Infinite recursion
     */
    
}
