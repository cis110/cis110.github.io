
public class RecursionPractice {
    
    
    public static void main(String[] args) { 
//        printInReverse(args[0]);
        countDown(Integer.parseInt(args[0]));
    }
    
    public static 
    
    // Prints out all positive numbers starting at x going down to 1
    public static void countDown(int x) {
        // Base case: stop when we go past 1
        if(x < 1) {
            System.out.println("x is < 1, so ending recursion");
            return;
        }
        else {
            System.out.println(x);
            countDown(x - 1);
        }
    }
    
    
    // Recursive function has two conceptual elements:
    // 1) The base case(s), in which we do NOT call the function recursively
    // 2) The iteration case(s), in which we DO call the function recursively
    // Typically want to determine the base cases first because they help us
    // infer what the iteration case(s) should be
//     0123
//    "ABCD"
    public static void printInReverse(String str) {
       // What input to this function would necessitate immediately returning?
        if(str.length() == 1) {
            System.out.print(str);
            return;
        }
        // Otherwise, let's print out one character in the String
        System.out.print(str.charAt(str.length() - 1));
        printInReverse(str.substring(0, str.length() - 1));
    }
    
}
