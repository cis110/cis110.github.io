/*
 * Let's create a set of data that a veterinarian's office might store to
 * track information about their animal patients
 * 
 * - Pet name
 * - Pet species
 * - Pet age
 * - Health status
 */

public class Pets {
    
    public static int findXLoop(String[] array, String x) {
        for(int i = 0; i < array.length; ++i) {
            if(array[i].equals(x)) {
                return i;
            }
        }
        return -1;
    }
    
    // Let's bundle up some of the code below into a function to make it
    // easier to re-use
    // TODO: Figure out the function's inputs
    public static void printPetInfo(String petName, String[] names,
                                    String[] species, double[] age,
                                    String[] health) {
        int indexOfPet = findXLoop(names, petName);
        if(indexOfPet == -1) {
            System.out.println("Database does not contain info for " + petName);
        }
        else {
            System.out.print(petName + "'s info: " + "\nSpecies: "
                                 + species[indexOfPet] + "\nAge: " + age[indexOfPet]
                                 + "\nHealth status: " + health[indexOfPet] + "\n");
        }
    }
    
    public static void printPetInfo(Pet p) {
        System.out.print(p.name + "'s info: " + "\nSpecies: "
                             + p.species + "\nAge: " + p.age
                             + "\nHealth status: " + p.healthStatus + "\n");
    }
    
    public static void main(String[] args) {
//        String[] names = {"Mittens", "Betsy", "Cupcake", "Bob"};
//        String[] species = {"Cat", "Cow", "Dog", "Iguana"};
//        double[] age = {5, 7, 3, 10};
//        String[] health = {"Healthy", "Lethargic", "Upset stomach", "Lazy"};
//        
//        printPetInfo(args[0], names, species, age, health);
        
        Pet p = new Pet("Mittens", "Cat", 5, "Healthy");
//        System.out.print(p.name + "'s info: " + "\nSpecies: "
//                             + p.species + "\nAge: " + p.age
//                             + "\nHealth status: " + p.healthStatus + "\n");
        
        Pet q = new Pet("Betsy", "Cow", 7, "Lethargic");
//        System.out.print(q.name + "'s info: " + "\nSpecies: "
//                             + q.species + "\nAge: " + q.age
//                             + "\nHealth status: " + q.healthStatus + "\n");
        
        // 2 scenarios in which I can invoke an argumentless constructor:
        // 1) I have defined NO constructors for my class, and Java provides a
        // default implementation of the argumentless constructor
        // 2) I have defined at least ONE constructor for my class, and one of
        // those constructors is argumentless.
        
        Pet example = new Pet();
        
        Pet[] pets = {p,
                      q,
                      new Pet("Cupcake", "Dog", 3, "Upset stomach")};
        for(int i = 0; i < pets.length; ++i) {
//            printPetInfo(pets[i]);
            pets[i].printInfo();
        }
    }
    
}
