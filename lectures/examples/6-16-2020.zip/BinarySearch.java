/**
 * Auto Generated Java Class.
 */
public class BinarySearch {
    
    
    public static void main(String[] args) { 
        //                 0        1       2          3      4         5        6
        String[] array = {"Larry", "Luna", "Quentin", "Sam", "Violet", "Wally", "Zendaya"};
        System.out.println(binarySearchLooped(array, args[0]));
    }
    
    // "Wrapper" function for binary search that hides the begin + end variables
    // from the user to make calling the function easier
    public static int binarySearch(String[] arr, String want) {
        return binarySearch(arr, want, 0, arr.length - 1);
    }
    
    // begin and end are the left and right bounds we want to search within our array
    public static int binarySearch(String[] arr, String want, int begin, int end) {
        // Base case(s) is/are
        // 1) When we know for certain the array does NOT contain the wanted String
        // 2) When we've found the element
        // Base case #1, we are certain the array does not contain the desired String
        if(arr == null || begin > end) {
            System.out.print("begin: " + begin + ", end: " + end + "\n");
            return -1;
        }
        
        int midpoint = begin + (end - begin) / 2;
        System.out.print("begin: " + begin + ", mid: " + midpoint + ", end: " + end + "\n");
        // String.compareTo tells us if the invoking String is less than, equal to,
        // or greater than the input String based on whether the result is -, 0, or +
        int compare = want.compareTo(arr[midpoint]);
        // Base case #2, we've found the desired element @ midpoint
        if(compare == 0) {
            return midpoint;
        }
        
        // Recursion condition 1, desired element is LESS THAN the element at the midpoint
        // Search all elements to the LEFT of the midpoint within our sub-array
        if(compare < 0) {
            int newBegin = begin;
            int newEnd = midpoint - 1;
            return binarySearch(arr, want, newBegin, newEnd);
        }
        // Recursion condition 2, desired element is GREATER THAN the element at the midpoint
        // Search all elements to the RIGHT of the midpoint within our sub-array
        if(compare > 0) {
            int newBegin = midpoint + 1;
            int newEnd = end;
            return binarySearch(arr, want, newBegin, newEnd);
        }
        
        return -1;
    }
    /*  0 1 2 3 4
     *  [][][][][]
     *  begin = 0, end = 4, mid = 2
     * begin = 3, end = 4, 
     */
    
    public static int binarySearchLooped(String[] arr, String want) {
        if(arr == null) {
            return -1;
        }
        int begin = 0;
        int end = arr.length - 1;
        while(begin < end) {
            int mid = begin + (end - begin) / 2;
            int compare = want.compareTo(arr[mid]);
            if(compare == 0) {
                return mid;
            }
            else if(compare < 0) {
                end = mid - 1;
            }
            else if(compare > 0) {
                begin = mid + 1;
            }
        }
        return -1;
    }
}
