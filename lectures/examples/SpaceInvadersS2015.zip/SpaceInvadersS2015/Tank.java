public class Tank {
  
  private final static double INITIAL_X_POSITION = 0.5; // center of screen
  private final static double Y_POSITION = 0;
  private final static double TANK_WIDTH = 0.02;
  private final static double TANK_HEIGHT = 0.03;
  private final static int INITIAL_TANK_LIFE = 3;
  private final static int MISSILE_RECHARGE_TIME = 10;
  
  
  private double xPosition;
  private int lifeRemaining;
  private int missileRechargeTimeRemaining = 0;
  
  // default constructor
  public Tank() {
    xPosition = INITIAL_X_POSITION;
    lifeRemaining = INITIAL_TANK_LIFE;
  }
  
  public void move() {
    xPosition = StdDraw.mouseX();
  }
  
  public Missile fireMissile() {
    if (missileRechargeTimeRemaining <= 0) {
      missileRechargeTimeRemaining = MISSILE_RECHARGE_TIME;
      return new Missile(xPosition, Y_POSITION + TANK_HEIGHT, false);
    } else {
      return null;
    }
  }
  
  // draw the tank at the current location
  public void display() {
    StdDraw.setPenColor(StdDraw.BLACK);
    StdDraw.filledRectangle(xPosition, Y_POSITION, 
                            TANK_WIDTH, TANK_HEIGHT);
    missileRechargeTimeRemaining--;
  }
  
  
  // get life remaining
  public int getLifeRemaining() { return lifeRemaining; }
  
  // get x position of tank
  public double getXPosition() { return xPosition; }
}