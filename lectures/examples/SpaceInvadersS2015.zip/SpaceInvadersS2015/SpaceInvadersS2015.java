public class SpaceInvadersS2015 {
  
  private static Tank tank = new Tank();
  private static Missile[] missiles = new Missile[120];
  private static Invader[] invaders = new Invader[100];
  private static int missileIdx = 0;
  private static int score = 0;
  
  public static void main(String[] args) {
    setup();
    while(true) {
      draw();
      StdDraw.show(20);
    }
  }
  
  public static void setup() {
    int i = 0;
    for (double x = 0.3; x < 0.7; x += 0.05) {
      for (double y = 0.5; y < 0.8; y += 0.1) {
        invaders[i++] = new Invader(x, y);
      }
    }
    
  }
  
  public static void draw() {
    StdDraw.clear(StdDraw.WHITE);
    
    // draw all objects
    tank.display();
    for (int i = 0; i < missiles.length; i++) {
      Missile missile = missiles[i];
      if (missile != null) {
        missile.display();
      }
    }
    for (Invader alien : invaders) {
      if (alien == null) continue; // skip nulls
      alien.display();
    }
    
    // display the score
    System.out.println("Score = " + score);
    
    // simulate object movement
    tank.move();
    for (Missile missile : missiles) {
      if (missile != null) {
        missile.move();
      }
    }
    for (Invader alien : invaders) {
      if (alien == null) continue;
      alien.move();
    }
    
    // handle alien bouncing
    for (Invader alien : invaders) {
      if (alien == null) continue;
      if (alien.getX() >= 1) {
        alien.bounceHorizontally();
        break;
      }
      if (alien.getX() <= 0) {
        alien.bounceHorizontally();
        break;
      }
    }
    
    // watch for the user firing a missile from the tank
    if (StdDraw.mousePressed()) {
      missiles[missileIdx] = tank.fireMissile();
      missileIdx = (missileIdx + 1) % missiles.length;
    }
    
    for (int i = 0; i < invaders.length; i++) {
      Invader alien = invaders[i];
      if (alien == null) continue; // skip null aliens
      
      // detect collision with each missile
      for (int j = 0; j < missiles.length; j++) {
        Missile m = missiles[j];
        if (m == null) continue; // skip null missiles
        
        if (alien.detectCollision(m)) {
          // destroy the alien
          invaders[i] = null;
          // destroy the missile
          missiles[j] = null;
          // increase score
          score++;
        }
      }
    }
  }
}
