public class Missile {
  
  private static final double SPEED = 0.01;

  private double x;
  private double y;
  private double dy;
  
  // constructor
  // x, y  - initial missile position
  // isBomb - true if the missile should fall like a bomb
  public Missile(double x, double y, boolean isBomb) {
    this.x = x;
    this.y = y;
    if (isBomb) 
      dy = -SPEED;
    else 
      dy = SPEED;
  }
  
  // getter for x
  public double getX() { return x; }
  
  // getter for y
  public double getY() { return y; }
  
  // draw the missile
  public void display() {
    StdDraw.setPenColor(StdDraw.RED);
    StdDraw.filledRectangle(x, y, 0.001, 0.01);
  }
  
  // update the missile's position
  public void move() {
    y += dy;
  }
  
  //  void destroy()
}