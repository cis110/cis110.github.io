public class Invader {
  
  private final static double INITIAL_SPEED = 0.01;
  private final static double WIDTH = 0.01;
  private final static double HEIGHT = 0.01;
  
  private double x;
  private double y;
  private static double dx = INITIAL_SPEED;
  
  public Invader (double x, double y) {
    this.x = x;
    this.y = y;
  }
  
  public void display() {
    StdDraw.setPenColor(StdDraw.GREEN);
    StdDraw.filledRectangle(x, y, WIDTH, HEIGHT);
  }
  
  public void move() {
    x += dx;
  }
  
  public void bounceHorizontally() {
    dx = -dx;
  }
  
  public double getX() { return x; }
                               
  
  //Missile shoot()
  //void increaseSpeed()
    
  public boolean detectCollision(Missile m) {
    double mx = m.getX();
    double my = m.getY();
    return (x-WIDTH <= mx) && (x+WIDTH >= mx) &&
           (y-HEIGHT <= my) && (y+HEIGHT >= my);
  }
    
}